export const formatPrice = (price) => {
  if (!Number.isFinite(price)) return 'N/A';
  let formatted;
  if (price >= 1) {
    formatted = price.toFixed(2);
  } else if (price >= 0.1) {
    formatted = price.toFixed(4);
  } else if (price >= 0.01) {
    formatted = price.toFixed(5);
  } else if (price >= 0.001) {
    formatted = price.toFixed(6);
  } else if (price >= 0.0001) {
    formatted = price.toFixed(8);
  } else {
    formatted = price.toPrecision(10);
  }
  // Remove unnecessary trailing zeros and decimal point
  formatted = parseFloat(formatted).toString();
  return `$${formatted}`;
};
