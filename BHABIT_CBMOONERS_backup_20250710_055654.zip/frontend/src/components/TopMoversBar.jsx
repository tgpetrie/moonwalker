import React from 'react';

// This component is not used in the CB4 design
const TopMoversBar = () => {
  return null;
};

export default TopMoversBar;
