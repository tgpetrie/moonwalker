import React, { useEffect, useState } from 'react';
import GainersTable from './components/GainersTable';
import LosersTable from './components/LosersTable';
import TopBannerScroll from './components/TopBannerScroll';
import BottomBannerScroll from './components/BottomBannerScroll';

// Live data polling interval (ms)
const POLL_INTERVAL = 30000;


export default function App() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [isConnected, setIsConnected] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [countdown, setCountdown] = useState(POLL_INTERVAL / 1000);

  // Poll backend connection and update countdown
  useEffect(() => {
    let intervalId;
    let countdownId;
    const checkConnection = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5001'}/api`);
        setIsConnected(response.ok);
      } catch (error) {
        setIsConnected(false);
      }
    };
    checkConnection();
    intervalId = setInterval(() => {
      checkConnection();
      setRefreshKey((prev) => prev + 1);
      setLastUpdate(new Date());
      setCountdown(POLL_INTERVAL / 1000);
    }, POLL_INTERVAL);
    countdownId = setInterval(() => {
      setCountdown((prev) => (prev > 1 ? prev - 1 : POLL_INTERVAL / 1000));
    }, 1000);
    return () => {
      clearInterval(intervalId);
      clearInterval(countdownId);
    };
  }, []);

  const refreshGainersAndLosers = () => {
    setRefreshKey((prev) => prev + 1);
    setLastUpdate(new Date());
    setCountdown(POLL_INTERVAL / 1000);
  };

  return (
    <div className="min-h-screen bg-dark text-white font-body relative">
      {/* Background Purple Rabbit - Centered */}
      <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-0">
        <img
          src="/purple-rabbit-bg.png"
          alt="BHABIT Background"
          className="w-96 h-96 sm:w-[32rem] sm:h-[32rem] lg:w-[40rem] lg:h-[40rem]"
          style={{ opacity: 0.10 }}
        />
      </div>
      {/* Move status/counter to top right */}
      <div className="fixed top-6 right-8 z-50 flex items-center gap-4">
        <div className="flex items-center gap-1 text-xs font-mono bg-black/40 px-3 py-1 rounded-full border border-gray-700">
          <span className="inline-block w-2 h-2 rounded-full bg-green-400 mr-1 animate-pulse"></span>
          <span className="font-bold">{String(countdown).padStart(2, '0')}</span>
        </div>
      </div>
      {/* Main Container with padding */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header Section */}
        <header className="flex flex-col items-center justify-center pt-8 pb-6">
          <div className="mb-4">
            <img
              src="/bhabit-logo.png"
              alt="BHABIT"
              className="h-20 sm:h-24 lg:h-28 animate-breathing"
            />
          </div>
          <p className="text-lg sm:text-xl text-purple font-mono italic tracking-wide">
            Profits by Impulse
          </p>
        </header>
        {/* Top Banner - 1H Price */}
        <div className="mb-8 -mx-16 sm:-mx-24 lg:-mx-32 xl:-mx-40">
          <TopBannerScroll />
        </div>
        {/* Refresh Button */}
        <div className="flex justify-center mb-8">
          <button
            onClick={refreshGainersAndLosers}
            className="px-6 py-3 bg-gradient-to-r from-orange to-pink text-white rounded-full font-bold text-sm tracking-wide pill-hover shadow-lg shadow-orange/30 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl"
          >
            Refresh Gainers & Losers
          </button>
        </div>
        {/* Main Content - Side by Side Panels */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Left Panel - Top Gainers */}
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <h2 className="text-xl font-headline font-bold text-blue tracking-wide">
              Top Gainers (3min)
            </h2>
          </div>
          <GainersTable key={`gainers-${refreshKey}`} />
        </div>
        {/* Right Panel - Top Losers */}
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <h2 className="text-xl font-headline font-bold text-pink tracking-wide">
              Top Losers (3min)
            </h2>
          </div>
          <LosersTable key={`losers-${refreshKey}`} />
        </div>
        </div>
        {/* Bottom Banner - 1H Volume */}
        <div className="mb-8 -mx-16 sm:-mx-24 lg:-mx-32 xl:-mx-40">
          <BottomBannerScroll />
        </div>
        {/* Footer */}
        <footer className="text-center py-8 text-muted text-sm font-mono">
          <p>
            © 2025 GUISAN DESIGN
            &nbsp;
            <span className="inline-flex items-center align-middle">
              <span className="text-pink-400 text-lg" style={{fontWeight: 900}}>⋆</span>
              <span className="text-purple text-lg mx-0.5" style={{fontWeight: 900}}>⋆</span>
              <span className="text-orange text-lg" style={{fontWeight: 900}}>⋆</span>
              <span className="text-purple text-lg mx-0.5" style={{fontWeight: 900}}>⋆</span>
              <span className="text-pink-400 text-lg" style={{fontWeight: 900}}>⋆</span>
            </span>
            &nbsp; BHABIT &nbsp;
            <span className="inline-flex items-center align-middle">
              <span className="text-pink-400 text-lg" style={{fontWeight: 900}}>⋆</span>
              <span className="text-purple text-lg mx-0.5" style={{fontWeight: 900}}>⋆</span>
              <span className="text-orange text-lg" style={{fontWeight: 900}}>⋆</span>
              <span className="text-purple text-lg mx-0.5" style={{fontWeight: 900}}>⋆</span>
              <span className="text-pink-400 text-lg" style={{fontWeight: 900}}>⋆</span>
            </span>
            &nbsp; TOM PETRIE
          </p>
        </footer>
      </div>
    </div>
  );
}
